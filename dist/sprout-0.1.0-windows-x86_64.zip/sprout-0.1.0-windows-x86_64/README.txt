Sprout - 2D multi-fluid sandbox (Windows x86-64 build)

Run sprout.exe. Needs a GPU with a Vulkan driver (any current NVIDIA/AMD/Intel driver).
Keep libunwind.dll next to sprout.exe.
Command-line options: sprout.exe --help
This is a cross-compiled build that has not been tested on Windows yet.
